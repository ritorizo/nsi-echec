import pygame
from position_tour import *
from x_coordonnees import *
from affichage import *
from position_cav import *
from position_fou import *
from position_reine import *
from position_roi import *
from position_pion import *

affichage()
