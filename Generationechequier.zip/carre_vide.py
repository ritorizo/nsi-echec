import pygame
from x_coordonnees import *
#marge dpionte/gauche echequier : 126
pygame.init()

# Donner un nom à la fenêtre

# x = 1-8, y = 1-8
cn = pygame.image.load("imgs/cn.png")
cb = pygame.image.load("imgs/cb.png")

cn = pygame.transform.scale(cn,(31,31))
cb = pygame.transform.scale(cb,(31,31))






  
